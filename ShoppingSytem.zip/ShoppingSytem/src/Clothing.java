public class Clothing extends Product {

    public Clothing(String productName, double price) {
        super(productName, price);
    }
    
}