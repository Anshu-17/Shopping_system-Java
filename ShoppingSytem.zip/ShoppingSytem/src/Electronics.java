public class Electronics extends Product {

    public Electronics(String productName, double price) {
        super(productName, price);
    }
}